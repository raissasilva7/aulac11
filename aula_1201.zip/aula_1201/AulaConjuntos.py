#Não guarda elemento repetido
#Ordena de forma aleatoria
#Parcialmente mutaveis

nome = {'Goku', 'Vegeta', 'Trucks', 'Gohan', 'Trunks', 'Goku'}
print(nome)

#ADICIONAR
nome.add('kami')

#DELETE
nome.remove('Vegeta')

#UPDATE NÃO ACEITA
#SE QUISER, TENHO QUE APAGAR E INSERIR DEPOIS

print(nome)